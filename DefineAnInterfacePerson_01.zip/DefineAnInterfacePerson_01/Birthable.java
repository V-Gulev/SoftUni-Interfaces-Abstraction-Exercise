package DefineAnInterfacePerson_01;

public interface Birthable {
    String getBirthDate();
}
