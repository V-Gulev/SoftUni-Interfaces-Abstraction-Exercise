package DefineAnInterfacePerson_01;

public interface Buyer {
    void buyFood();
    int getFood();
}
