package DefineAnInterfacePerson_01;

public interface Identifiable {
    String getId();
}
